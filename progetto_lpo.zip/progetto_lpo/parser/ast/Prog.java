package progetto_lpo.parser.ast;

public interface Prog extends AST {
}
