package progetto_lpo.parser.ast;

public interface Stmt extends AST {
}
