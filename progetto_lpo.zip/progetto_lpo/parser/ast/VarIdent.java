package progetto_lpo.parser.ast;

public interface VarIdent extends Exp {
	String getName();
}
