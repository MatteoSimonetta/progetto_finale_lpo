package progetto_lpo.parser.ast;

public interface StmtSeq extends AST {
}
