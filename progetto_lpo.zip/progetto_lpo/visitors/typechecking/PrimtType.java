package progetto_lpo.visitors.typechecking;

public enum PrimtType implements Type {
	BOOL, INT, SEASON;
}
